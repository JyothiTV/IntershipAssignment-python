# MergeSort written in python 

def mergesort(inarr): 
  if len(inarr) >1: 
      mid = len(inarr)//2 #Finding the mid of the array 
      LArr = inarr[:mid] #Dividing the array elements 
      RArr = inarr[mid:] #into two parts 
      mergesort(LArr) #Sort the first half of Array
      mergesort(RArr) #Sort the second half of Array
      i =0
      j = 0
      k = 0
      # Copy data to temparory arrays LArr[] and RArr[] 
      while i < len(LArr) and j < len(RArr): 
          if LArr[i] < RArr[j]: 
              inarr[k] = LArr[i]
              i+=1
          else:
              inarr[k] = RArr[j]
              j+=1
          k+=1	
      # Checking if any element is left 
      while i < len(LArr): 
          inarr[k] = LArr[i]
          i+=1
          k+=1
		
      while j < len(RArr): 
          inarr[k] = RArr[j]
          j+=1
          k+=1

# Code to print the Array 
def printList(inarr):
    for i in range(len(inarr)):
        print(inarr[i],end=" ")
    print()

# code to call the above code 
if __name__ == '__main__': 
    n=int(input("Enter number of elements into array"))
    inputarray=[]
    print("Enter elements into array")
    for i in range(0,n):
        inputarray.append(int(input()))
    print ("Given array is", end="\n") 
    printList(inputarray) 
    mergesort(inputarray) 
    print("Sorted array is: ", end="\n") 
    printList(inputarray) 


