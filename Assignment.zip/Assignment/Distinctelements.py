from collections import OrderedDict 
  
def printDistinct(inputarray): 
     # convert Array-list into dictionary 
     orddict = OrderedDict.fromkeys(inputarray) 
  
     # iterate through dictionary and get list of keys.List of keys will be resultant distinct elements in array 
     result = [ key for (key, value) in orddict.items() ] 
  
     # concatenate list of elements with ', ' and print 
     print (', '.join(map(str, result)))   
  
# Main program 
if __name__ == "__main__": 
    n=int(input("Enter number of elements into array"))
    inputarray=[]
    print("Enter elements into array")
    for i in range(0,n):
        inputarray.append(int(input()))
    printDistinct(inputarray) 